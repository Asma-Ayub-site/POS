<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deleteRecords'])) {
   
    file_put_contents('bills_record.json', json_encode([]));
    
    header('Location: ' . $_SERVER['PHP_SELF']);
    exit();
}


$json_data = file_get_contents('bills_record.json');
$bills = json_decode($json_data, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    die("Invalid JSON data in bills_record.json.");
}


$records = [];


foreach ($bills as $bill) {
    $table_number = $bill['tableNumber'];
    $waiter_name = $bill['waiterName'];
    $timestamp = $bill['timestamp'];
    $bill_items = $bill['bill'];

    
    if (!isset($records[$table_number][$waiter_name])) {
        $records[$table_number][$waiter_name] = [];
    }

   
    $records[$table_number][$waiter_name][] = [
        'timestamp' => $timestamp,
        'bill_items' => $bill_items,
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <title>Table and Waiter Records</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            background-color:white;
        }
        table {
            width: 80%;
            border-collapse: collapse;
            margin-bottom: 20px;
            background-color: white;
        }
        th, td {
            padding: 10px;
            border: 2px solid #ddd;
            text-align: left;
        }
        th {
            background-color:black;
        }
        .bill-items {
            margin: 0;
            padding: 0;
            list-style-type: none;
        }
        .bill-items li {
            padding: 5px 0;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color:black;
            padding: 15px 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            color:black;
        }
        .navbar .logo img {
            height: 50px;
        }
        .nav-links {
            list-style: none;
            display: flex;
            gap: 20px;
            margin: 0;
            padding: 0;
        }
        .nav-links li {
            display: inline;
        }
        .nav-links a {
            text-decoration: none;
            color: white;
            font-size: 18px;
            padding: 8px 12px;
            transition: background 0.3s ease;
            border-radius: 5px;
        }
        .nav-links a:hover {
            background: #555;
        }
        .btn {
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin: 10px 5px;
        }
        .delete-btn {
            background-color: #ff4d4d;
            color: white;
        }
        .delete-btn:hover {
            background-color: #cc0000;
        }
        .print-btn {
            background-color: #4CAF50;
            color: white;
        }
        .print-btn:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">
            <img src="logo.png" alt="Logo">
        </div>
        <ul class="nav-links">
             
            
            <li><a href="view_bills.php"><i class="fas fa-file"> Record</i></a></li>
            <li><a href="index.html"><i class="fas fa-house"> Home</i></a></li>
        </ul>
    </nav>

    
    <?php if (empty($records)) : ?>
        <p>No records found.</p>
    <?php else : ?>
        <?php foreach ($records as $table_number => $waiters) : ?>
            <h2>Table <?php echo htmlspecialchars($table_number); ?></h2>
            <?php foreach ($waiters as $waiter_name => $bills) : ?>
                <h3>Cover By: <?php echo htmlspecialchars($waiter_name); ?></h3>
                <table>
                    <thead>
                        <tr>
                            <th>Timestamp</th>
                            <th>Bill Items</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($bills as $bill) : ?>
                            <tr>
                                <td><?php echo htmlspecialchars($bill['timestamp']); ?></td>
                                <td>
                                    <ul class="bill-items">
                                        <?php foreach ($bill['bill_items'] as $item) : ?>
                                            <li>
                                                <?php echo htmlspecialchars($item['item']); ?> -
                                                Rs:<?php echo htmlspecialchars($item['price']); ?> -
                                                Qty: <?php echo htmlspecialchars($item['quantity']); ?>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endforeach; ?>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>