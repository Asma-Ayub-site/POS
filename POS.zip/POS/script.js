$(document).ready(function() {
    $("#stockForm").submit(function(e) {
        e.preventDefault();
        
        var formData = new FormData(this);

        $.ajax({
            url: 'insert_stock.php', 
            type: 'POST',
            data: formData,
            contentType: false, 
            processData: false,
            success: function(response) {
                alert("Product added successfully!");
                $("#stockForm")[0].reset(); 
            },
            error: function() {
                alert("There was an error. Please try again.");
            }
        });
    });
});
