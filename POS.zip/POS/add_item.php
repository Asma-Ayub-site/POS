<?php
$servername = "127.0.0.1";
$username = "u812793309_Admin";
$password = "bangtanseolO7";
$database = "u812793309_POS";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$category = $_POST['category'];
$name = $_POST['name'];
$price = $_POST['price'];
$imagePath = $_POST['image_path'];

$sql = "INSERT INTO stock (category, name, price, image_path) VALUES ('$category', '$name', $price, '$imagePath')";

if ($conn->query ($sql)) {
    echo "Item added successfully!";
} else {
    echo "Error: " . $conn->error;
}

$conn->close();
?>