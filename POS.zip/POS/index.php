<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database credentials
$servername = "127.0.0.1";
$username = "u812793309_Admin";
$password = "bangtanseolO7";
$database = "u812793309_POS";

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if it's a login or registration request
    if (isset($_POST["login"])) {
        // Login logic
        if (empty($_POST["username"]) || empty($_POST["password"])) {
            $error_message = "Please fill in all fields.";
        } else {
            $username = trim($_POST["username"]);
            $password = trim($_POST["password"]);

            // Prepare SQL statement to prevent SQL injection
            $sql = "SELECT * FROM user WHERE username = ?";
            $stmt = $conn->prepare($sql);

            if ($stmt === false) {
                die("Error preparing statement: " . $conn->error);
            }

            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                if (password_verify($password, $row["password"])) {
                    $_SESSION["username"] = $username;
                    $_SESSION["email"] = $row["email"];
                    header("Location: dashboard.html"); // Redirect to dashboard
                    exit();
                } else {
                    $error_message = "Incorrect password.";
                }
            } else {
                $error_message = "User not found.";
            }
            $stmt->close();
        }
    } elseif (isset($_POST["register"])) {
        // Registration logic
        if (empty($_POST["username"]) || empty($_POST["email"]) || empty($_POST["password"])) {
            $error_message = "Please fill in all fields.";
        } else {
            $username = trim($_POST["username"]);
            $email = trim($_POST["email"]);
            $password = trim($_POST["password"]);

            // Validate email
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $error_message = "Invalid email format.";
            } else {
                // Hash the password
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);

                // Insert user into the database
                $sql = "INSERT INTO user (username, email, password) VALUES (?, ?, ?)";
                $stmt = $conn->prepare($sql);

                if ($stmt === false) {
                    die("Error preparing statement: " . $conn->error);
                }

                $stmt->bind_param("sss", $username, $email, $hashed_password);
                if ($stmt->execute()) {
                    $error_message = "User registered successfully!";
                } else {
                    $error_message = "Error registering user: " . $stmt->error;
                }
                $stmt->close();
            }
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login / Register</title>
    <style>
        body {
            font-family: sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-image: url("uploads/back.jpg");
            height: 500px; 
            background-position: center; 
            background-repeat: no-repeat; 
            background-size: cover; 
        }

        .auth-container {
            background-color: black;
            color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            width: 300px;
        }

        .auth-container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: white;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
        }

        .form-group input {
            width: calc(100% - 12px);
            padding: 6px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .form-group button {
            width: 100%;
            padding: 10px;
            background-color:white;
            color: black;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .form-group button:hover {
            background-color:rgb(138, 136, 112);
        }

        .error-message {
            color: red;
            text-align: center;
            margin-top: 10px;
        }

        .toggle-auth {
            text-align: center;
            margin-top: 10px;
        }

        .toggle-auth a {
            color: #007bff;
            text-decoration: none;
        }

        .toggle-auth a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="auth-container">
        <h2 id="auth-title">Login</h2>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="form-group" id="email-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email">
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <div class="form-group">
                <button type="submit" name="login" id="login-btn">Login</button>
                <button type="submit" name="register" id="register-btn" style="display: none;">Register</button>
            </div>
            <?php if (!empty($error_message)): ?>
                <div class="error-message"><?php echo $error_message; ?></div>
            <?php endif; ?>
        </form>
        <div class="toggle-auth">
            <a href="#" id="toggle-link">Don't have an account? Register</a>
        </div>
    </div>

    <script>
        // Toggle between login and registration forms
        const authTitle = document.getElementById('auth-title');
        const emailGroup = document.getElementById('email-group');
        const loginBtn = document.getElementById('login-btn');
        const registerBtn = document.getElementById('register-btn');
        const toggleLink = document.getElementById('toggle-link');

        toggleLink.addEventListener('click', (e) => {
            e.preventDefault();
            if (authTitle.textContent === "Login") {
                authTitle.textContent = "Register";
                emailGroup.style.display = "block";
                loginBtn.style.display = "none";
                registerBtn.style.display = "block";
                toggleLink.textContent = "Already have an account? Login";
            } else {
                authTitle.textContent = "Login";
                emailGroup.style.display = "none";
                loginBtn.style.display = "block";
                registerBtn.style.display = "none";
                toggleLink.textContent = "Don't have an account? Register";
            }
        });
    </script>
</body>
</html>