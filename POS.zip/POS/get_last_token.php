<?php
include 'db_connection.php';

$query = "SELECT MAX(token_number) as last_token FROM bills";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);

echo $row['last_token'] ? $row['last_token'] : 0;

mysqli_close($conn);
?>