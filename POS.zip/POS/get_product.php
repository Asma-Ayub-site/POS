<?php
header('Content-Type: application/json');

$conn = new mysqli('127.0.0.1', 'u812793309_Admin', '', 'stock_management');

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = $conn->query("SELECT * FROM products");

$products = [];
while ($row = $result->fetch_assoc()) {
    $products[] = $row;
}

echo json_encode($products);

$conn->close();
?>