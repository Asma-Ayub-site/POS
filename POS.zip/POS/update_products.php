<?php
header('Content-Type: application/json');

$servername = "127.0.0.1";
$username = "u812793309_Admin";
$password = "bangtanseolO7";
$database = "u812793309_POS";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
}

$data = json_decode(file_get_contents('php://input'), true);

$id = $data['id'];
$category = $data['category'];
$name = $data['name'];
$price = $data['price'];
$imagePath = $data['image_path'];

$stmt = $conn->prepare("UPDATE stock SET category = ?, name = ?, price = ?, image_path = ? WHERE id = ?");
$stmt->bind_param("ssdsi", $category, $name, $price, $imagePath, $id);

if ($stmt->execute()) {
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false, 'message' => $stmt->error]);
}

$stmt->close();
$conn->close();
?>