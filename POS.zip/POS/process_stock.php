<?php
$servername = "127.0.0.1";
$username = "u812793309_Admin";
$password = "bangtanseolO7";
$database = "u812793309_POS";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $category = trim($_POST["category"]);
    $name = trim($_POST["name"]);
    $price = floatval($_POST["price"]);

    $imagePath = "";
    if (isset($_FILES["image"]) && $_FILES["image"]["error"] == 0) {
        $allowed = ["jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png" ,"avif" => "image/avif"];
        $filename = $_FILES["image"]["name"];
        $filetype = $_FILES["image"]["type"];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if (array_key_exists($ext, $allowed) && in_array($filetype, $allowed)) {
            $targetDir = "uploads/";
            if (!file_exists($targetDir)) {
                mkdir($targetDir, 0755, true);
            }
            $targetFile = $targetDir . uniqid() . "_" . basename($filename);

            if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
                $imagePath = $targetFile;
            } else {
                echo "Error: There was a problem uploading your file.";
                exit;
            }
        } else {
            echo "Error: Invalid file format.";
            exit;
        }
    }

    $sql = "INSERT INTO stock (category, name, image_path, price) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("sssd", $category, $name, $imagePath, $price);
        if ($stmt->execute()) {
            echo "Item added successfully!";
        } else {
            echo "Error adding item: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Error preparing statement: " . $conn->error;
    }
}

$conn->close();
?>