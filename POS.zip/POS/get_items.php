<?php
$servername = "127.0.0.1";
$username = "u812793309_Admin";
$password = "bangtanseolO7";
$database = "u812793309_POS";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$category = isset($_GET['category']) ? $_GET['category'] : null;
$sql = $category ? "SELECT * FROM stock WHERE category = '$category'" : "SELECT * FROM stock";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div class='item-card' data-name='{$row['name']}' data-price='{$row['price']}'>
                <img src='{$row['image_path']}' alt='{$row['name']}'>
                <h3>{$row['name']}</h3>
                <p>Price: {$row['price']}</p>
              </div>";
    }
} else {
    echo "<p>No items found</p>";
}

$conn->close();
?>