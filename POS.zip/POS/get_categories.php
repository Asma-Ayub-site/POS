<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);


$servername = "127.0.0.1";
$username = "u812793309_Admin";
$password = "bangtanseolO7";
$database = "u812793309_POS";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT DISTINCT category FROM stock";
$result = $conn->query($sql);

if (!$result) {
    die("Error in query: " . $conn->error);
}

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<li data-category='{$row['category']}'>{$row['category']}</li>";
    }
} else {
    echo "<li>No categories found</li>";
}

$conn->close();
?>
