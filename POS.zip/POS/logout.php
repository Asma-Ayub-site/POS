<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Clear session data
$_SESSION = array();

// Delete the session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    @setcookie(
        session_name(), 
        '', 
        time() - 42000,
        $params["path"] ?? '/',
        $params["domain"] ?? '',
        $params["secure"] ?? false,
        $params["httponly"] ?? false
    );
}

// Destroy the session
@session_destroy();

// Clear any existing output
if (ob_get_length()) {
    ob_end_clean();
}

// Redirect to login page
header("Location: index.php");
exit();
?>