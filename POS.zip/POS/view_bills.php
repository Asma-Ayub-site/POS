<?php
$filePath = 'bills_record.json';

if (!file_exists($filePath)) {
    $bills = [];
} else {
    $fileContent = file_get_contents($filePath);
    $bills = json_decode($fileContent, true) ?? [];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['deleteRecords'])) {
        file_put_contents($filePath, json_encode([]));
        header("Location: view_bills.php");
        exit();
    } elseif (isset($_POST['addItems'])) {
        $index = $_POST['index'];
        $items = json_decode($_POST['items'], true);
        $waiterName = $_POST['waiterName'];
        $tableNumber = $_POST['tableNumber'];
        $tokenNumber = $_POST['tokenNumber'];

        if (isset($bills[$index])) {
            if (!empty($waiterName)) {
                $bills[$index]['waiterName'] = $waiterName;
            }
            if (!empty($tableNumber)) {
                $bills[$index]['tableNumber'] = $tableNumber;
            }
            if (!empty($tokenNumber)) {
                $bills[$index]['tokenNumber'] = $tokenNumber;
            }

            foreach ($items as $newItem) {
                $itemExists = false;
                foreach ($bills[$index]['bill'] as &$existingItem) {
                    if (strtolower($existingItem['item']) === strtolower($newItem['item'])) {
                        $existingItem['quantity'] += $newItem['quantity'];
                        $itemExists = true;
                        break;
                    }
                }
                if (!$itemExists) {
                    $bills[$index]['bill'][] = $newItem;
                }
            }
            file_put_contents($filePath, json_encode($bills));
            echo json_encode(['success' => true, 'message' => 'Items added successfully']);
            exit();
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid bill index']);
            exit();
        }
    } elseif (isset($_POST['deleteItem'])) {
        $billIndex = $_POST['billIndex'];
        $itemIndex = $_POST['itemIndex'];

        if (isset($bills[$billIndex]['bill'][$itemIndex])) {
            array_splice($bills[$billIndex]['bill'], $itemIndex, 1);
            file_put_contents($filePath, json_encode($bills));
            echo json_encode(['success' => true, 'message' => 'Item deleted successfully']);
            exit();
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid bill or item index']);
            exit();
        }
    }
}

// Calculate total revenue and total orders
$totalRevenue = 0;
$totalOrders = count($bills);

foreach ($bills as $bill) {
    foreach ($bill['bill'] as $item) {
        $totalRevenue += $item['quantity'] * $item['price'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <title>View Bills</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: white;
            margin: 0;
            padding: 0;
            color: black;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color:black;
            padding: 15px 20px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .navbar .logo img {
            height: 50px;
        }
        .nav-links {
            list-style: none;
            display: flex;
            gap: 20px;
            margin: 0;
            padding: 0;
        }
        .nav-links li {
            display: inline;
        }
        .nav-links a {
            text-decoration: none;
            color: white;
            font-size: 18px;
            padding: 8px 12px;
            transition: background 0.3s ease;
            border-radius: 5px;
        }
        .nav-links a:hover {
            background: #555;
        }
        .container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            padding: 20px;
        }
        .left-section {
            flex: 1;
            max-width: 300px;
        }
        .right-section {
            flex: 3;
            min-width: 300px;
        }
        .search-bars {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f8f9fa;
            padding: 12px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            gap: 10px;
        }
        .search-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f8f9fa;
            padding: 4px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .search-bar form {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .search-bar input[type="text"] {
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 200px;
        }
        .search-bar .btn {
            padding: 8px 8px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: bold;
            transition: 0.3s;
        }
        .search-bar .btn-primary {
            background-color:black;
            color: white;
        }
        .search-bar .btn-primary:hover {
            background: white;
            color: black;
        }
        .search-bar .delete-btn {
            background:red;
            color: white;
        }
        .search-bar .delete-btn:hover {
            background: red;
        }
        .search-bar .print-btn {
            background: rgb(255, 215, 0);
            color: white;
        }
        .search-bar .print-btn:hover {
            background: white;
            color: black;
        }
        .search-bar .restart-btn {
            background-color:rgb(255, 215, 0);
            color: white;
        }
        .search-bar .restart-btn:hover {
            background: white;
            color: black;
        }
        .revenue-container {
            display: flex;
            flex-direction:row;
            gap: 9px;
            text-align: center;
            
        }
        .revenue-box {
            background-color: #fff;
            padding: 10px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .revenue-box h3 {
            margin: 0 0 10px 0;
            font-size: 18px;
            color: black;
        }
        .revenue-box p {
            margin: 0;
            font-size: 24px;
            font-weight: bold;
            color:black;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: black;
        }

        .container {
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            margin: 20px auto;
            max-width: 1200px;
        }

        /* Table Styles */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: black;
            font-weight: bold;
            color: white;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        td ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        td ul li {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }

        td ul li button {
            background-color: black;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            font-size: 0.9rem;
        }

        td ul li button:hover {
            background-color: #b02a37;
        }

        /* Button Styles */
        button {
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 1rem;
            transition: 0.3s;
        }

        button:hover {
            opacity: 0.9;
        }

        .btn-add {
            background-color:rgb(255, 215, 0);
            color: white;
        }

        .btn-receipt {
            background-color: rgb(255, 215, 0);
            color: white;
        }

        .btn-remove {
            background-color:rgb(255,0,0);
            color: white;
        }

        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(58, 143, 110, 0.5);
            justify-content: center;
            align-items: center;
        }

        .modal-content {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        .modal-content h2 {
            margin-top: 0;
            color: #333;
        }

        .modal-content label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
        }

        .modal-content input {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .modal-content button {
            margin-right: 10px;
            background-color:black; 
            color: white;
        }

        .modal-content ul {
            list-style: none;
            padding: 0;
        }

        .modal-content ul li {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            .left-section, .right-section {
                max-width: 100%;
            }
            .search-bar {
                flex-direction: column;
                gap: 10px;
            }
            .search-bar form {
                width: 100%;
            }
            .search-bar input[type="text"] {
                width: 100%;
            }
            .search-bar .btn {
                width: 100%;
            }
            @media (max-width: 768px) {
            table {
                display: block;
                overflow-x: auto;
            }

            .modal-content {
                width: 90%;
            }
        }
        }
    </style>
    <script>
         let userAddedItems = [];

function openAddItemsModal(index) {
    localStorage.setItem('selectedBillIndex', index);
    userAddedItems = [];
    const selectedItemsList = document.getElementById('selectedItemsList');
    selectedItemsList.innerHTML = '';
    const modal = document.getElementById('addItemsModal');
    modal.style.display = 'flex';
}

function closeAddItemsModal() {
    const modal = document.getElementById('addItemsModal');
    modal.style.display = 'none';
}

function addItemToList() {
    const itemName = document.getElementById('itemName').value;
    const itemPrice = parseFloat(document.getElementById('itemPrice').value);
    const itemQuantity = parseInt(document.getElementById('itemQuantity').value);

    if (itemName && !isNaN(itemPrice) && !isNaN(itemQuantity)) {
        const totalPrice = itemPrice * itemQuantity;

        const newItem = {
            id: userAddedItems.length + 1,
            name: itemName,
            price: itemPrice,
            quantity: itemQuantity,
            total: totalPrice
        };


        userAddedItems.push(newItem);

        const selectedItemsList = document.getElementById('selectedItemsList');
        const li = document.createElement('li');
        li.innerHTML = `
            <span>${newItem.name} (₨${newItem.price} x ${newItem.quantity} = ₨${newItem.total})</span>
            <button onclick="removeItemFromList(${newItem.id})">Remove</button>
        `;
        selectedItemsList.appendChild(li);
        document.getElementById('itemName').value = '';
        document.getElementById('itemPrice').value = '';
        document.getElementById('itemQuantity').value = 1;
    } else {
        alert('Please fill in all fields correctly.');
    }
}

function removeItemFromList(itemId) {
    userAddedItems = userAddedItems.filter(item => item.id !== itemId);
    const selectedItemsList = document.getElementById('selectedItemsList');
    selectedItemsList.innerHTML = '';
    userAddedItems.forEach(item => {
        const li = document.createElement('li');
        li.innerHTML = `
            <span>${item.name} (₨${item.price} x ${item.quantity} = ₨${item.total})</span>
            <button onclick="removeItemFromList(${item.id})">Remove</button>
        `;
        selectedItemsList.appendChild(li);
    });
}

function addSelectedItems() {
console.log("Adding selected items..."); 
const selectedBillIndex = localStorage.getItem('selectedBillIndex');
const waiterName = document.getElementById('waiterName').value;
const tableNumber = document.getElementById('tableNumber').value;

if (userAddedItems.length === 0) {
alert('No items selected.');
return;
}

const selectedItems = userAddedItems.map(item => ({
item: item.name,
quantity: item.quantity,
price: item.price,
total: item.total
}));

fetch('view_bills.php', {
method: 'POST',
headers: {
    'Content-Type': 'application/x-www-form-urlencoded'
},
body: `addItems=true&index=${selectedBillIndex}&items=${JSON.stringify(selectedItems)}&waiterName=${encodeURIComponent(waiterName)}&tableNumber=${encodeURIComponent(tableNumber)}`
})
.then(response => response.json())
.then(data => {
if (data.success) {
    alert('Items added successfully!');
    location.reload();
} else {
    alert('Failed to add items: ' + data.message);
}
})
.catch(error => console.error('Error:', error));

closeAddItemsModal();
}

function generateSaleReceipt(index) {
const bill = <?php echo json_encode($bills); ?>[index];
if (!bill) {
alert('Invalid bill index.');
return;
}

const paymentMethod = prompt('Enter payment method (Cash, JazzCash, EasyPaisa):');
if (!paymentMethod) {
alert('Payment method is required.');
return;
}

const discountPercentage = parseFloat(prompt('Enter discount percentage (e.g., 10 for 10%):')) || 0;
if (isNaN(discountPercentage) || discountPercentage < 0 || discountPercentage > 100) {
alert('Invalid discount percentage! Please enter a number between 0 and 100.');
return;
}

const totalAmount = bill.bill.reduce((sum, item) => sum + (item.quantity * item.price), 0);
const discountAmount = (totalAmount * discountPercentage) / 100;
const finalAmount = totalAmount - discountAmount;

const receiptContent = `
<html>
<head>
    <title>Sale Receipt</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            text-align: center;
        }
        .logo-container {
            text-align: center;
            margin-bottom: 15px;
        }
        .logo-container img {
            max-width: 150px;
            height: auto;
        }
        h2 {
            margin: 10px 0;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        th, td {
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f0f0f0;
        }
        .total-container {
            margin-top: 15px;
            font-size: 18px;
            font-weight: bold;
        }
        #datetime strong {
            margin-right: 15px;
            display: inline-block;
        }
        #number strong {
            margin-right: 19px;
            display: inline-block;
        }
    </style>
</head>
<body>
    <h2>Sale Receipt</h2>
    <hr>
    <p id="datetime"><strong>Date & Time:</strong>&nbsp ${bill.timestamp}</p>
    <table>
        <thead>
            <tr>
                <th>Item</th>
                <th>Quantity</th>
                <th>Price</th>
            </tr>
        </thead>
        <tbody>
            ${bill.bill.map(item => `
                <tr>
                    <td>${item.item}</td>
                    <td>${item.quantity}</td>
                    <td>₨${(item.quantity * item.price).toFixed(2)}</td>
                </tr>
            `).join('')}
        </tbody>
    </table>
    <hr>
    <div class="total-container">
        <p><strong>Total Bill:</strong> ₨${totalAmount.toFixed(2)}</p>
        <p><strong>Discount (${discountPercentage}%):</strong> ₨${discountAmount.toFixed(2)}</p>
        <p><strong>Final Amount:</strong> ₨${finalAmount.toFixed(2)}</p>
        <p><strong>Payment Method:</strong> ${paymentMethod}</p>
    </div>
    <hr>
    <p>Thank you for your visit!</p>
    <hr>
</body>
</html>
`;

const receiptWindow = window.open('', '_blank', 'width=600,height=600');
receiptWindow.document.write(receiptContent);
receiptWindow.document.close();
receiptWindow.print();
receiptWindow.onafterprint = function () { receiptWindow.close(); };
}
function searchBills() {
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    const rows = document.querySelectorAll('table tbody tr');
    let found = false;

    rows.forEach(row => {
        const tokenNumber = row.cells[0].textContent.toLowerCase();
        if (tokenNumber.includes(searchTerm)) {
            row.style.display = '';
            found = true;
        } else {
            row.style.display = 'none';
        }
    });

    if (!found) {
        alert('No matching bill found for the given Token Number.');
    }
}

function restartPage() {
    location.reload(); 
}
let selectedItemId = null;

function openEditModal(billIndex, itemIndex) {
    selectedItemId = { billIndex, itemIndex };
    document.getElementById('editItemModal').style.display = 'block';
}

function closeEditModal() {
    document.getElementById('editItemModal').style.display = 'none';
    selectedItemId = null;
}

function deleteItem() {
    if (selectedItemId) {
        const { billIndex, itemIndex } = selectedItemId;

        fetch('view_bills.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: `deleteItem=true&billIndex=${billIndex}&itemIndex=${itemIndex}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Item deleted successfully!');
                location.reload();
            } else {
                alert('Failed to delete item: ' + data.message);
            }
        })
        .catch(error => console.error('Error:', error));

        closeEditModal();
        location.reload();
    } else {
        console.error("No item selected for deletion.");
    }
}
    </script>
</head>
<body>
    <nav class="navbar">
        <div class="logo">
            <img src="logo.png" alt="Logo">
        </div>
        <ul class="nav-links">
            <li><a href="index.html"><i class="fa fa-house"></i></a></li>
            <li><a href="table_cover.php"><i class="fa-solid fa-clone"> T&W</i></a></li>
        </ul>
    </nav>

    <div class="search-bar">
        <form onsubmit="searchBills(); return false;" class="search-bar">
            <input type="text" id="searchInput" placeholder="Search by Token Number...">
            <input type="submit" name="submit" value="Search" class="btn btn-primary">
        </form>
        <div class="search-bars search-bar ">
        <form method="POST" onsubmit="return confirm('Are you sure you want to delete all records?');">
            <button type="submit" name="deleteRecords" class="btn delete-btn"><i class="fa fa-trash"></i></button>
        </form>
        <button class="btn print-btn" onclick="window.print();">Print Records</button>
        <button class="btn restart-btn" onclick="restartPage()">Refresh</button>
        </div>
    </div>

    <!-- Revenue and Orders Section -->
    <div class="revenue-container">
        <div class="revenue-box">
            <h3>Total Revenue</h3>
            <p>₨<?php echo number_format($totalRevenue, 2); ?></p>
        </div>
        <div class="revenue-box">
            <h3>Total Orders</h3>
            <p><?php echo $totalOrders; ?></p>
        </div>
    </div>
     
    <div class="container">
        <?php if (!empty($bills)): ?>
            <table>
                <thead>
                    <tr>
                        <th>Token Number</th>
                        <th>Date & Time</th>
                        <th>Table Number</th>
                        <th>Waiter Name</th>
                        <th>Items</th>
                        <th>Total Amount</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($bills as $index => $bill): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($bill['tokenNumber'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($bill['timestamp'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($bill['tableNumber'] ?? 'N/A'); ?></td>
                            <td><?php echo htmlspecialchars($bill['waiterName'] ?? 'N/A'); ?></td>
                            <td>
                                <ul>
                                    <?php foreach ($bill['bill'] as $itemIndex => $item): ?>
                                        <li>
                                            <?php echo htmlspecialchars($item['item'] ?? 'N/A'); ?>
                                            (x<?php echo htmlspecialchars($item['quantity'] ?? 'N/A'); ?>)
                                            - ₨<?php echo ($item['quantity'] * $item['price']); ?>
                                            <button onclick="openEditModal(<?php echo $index; ?>, <?php echo $itemIndex; ?>)"><i class="fa fa-trash"></i></button>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            </td>
                            <td>
                                ₨<?php echo array_reduce($bill['bill'], function($sum, $item) {
                                    return $sum + ($item['quantity'] * $item['price']);
                                }, 0); ?>
                            </td>
                            <td>
                                <button class="btn-add" onclick="openAddItemsModal(<?php echo $index; ?>)">Add</button>
                                <button  class="btn-receipt"onclick="generateSaleReceipt(<?php echo $index; ?>)">Sale Receipt</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No bills recorded yet.</p>
        <?php endif; ?>
    </div>

    <!-- Modal for adding items -->
    <div id="addItemsModal" class="modal">
        <div class="modal-content">
            <h2>Add Items to Bill</h2>
            <form id="addItemForm">
                <div>
                    <label for="waiterName">Waiter Name:</label>
                    <input type="text" id="waiterName" placeholder="Enter Waiter Name" required>
                    <label for="tableNumber">Table Number:</label>
                    <input type="text" id="tableNumber" placeholder="Enter Table Number" required>
                    <label for="itemName">Item Name:</label>
                    <input type="text" id="itemName" required>
                </div>
                <div>
                    <label for="itemPrice">Item Price:</label>
                    <input type="number" id="itemPrice" min="0" step="0.01" required>
                </div>
                <div>
                    <label for="itemQuantity">Quantity:</label>
                    <input type="number" id="itemQuantity" min="1" value="1" required>
                </div>
                <button type="button" onclick="addItemToList()">Add Item</button>
            </form>
            <ul id="selectedItemsList"></ul>
            <button onclick="addSelectedItems()">Add Selected Items to Bill</button>
            <button onclick="closeAddItemsModal()">Close</button>
        </div>
    </div>

    <!-- Modal for removing items -->
    <div id="editItemModal" class="modal">
        <div class="modal-content">
            <h2>Remove Item</h2>
            <p>Are you sure you want to remove this item?</p>
            <button onclick="deleteItem()"><i class="fa fa-trash"></i></button>
            <button onclick="closeEditModal()">Cancel</button>
        </div>
    </div>
</body>
</html>