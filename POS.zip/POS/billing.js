$(document).ready(function () {
    let billItems = JSON.parse(sessionStorage.getItem('billItems')) || []; // Load bill items from session storage
    let lastTokenNumber = parseInt(sessionStorage.getItem('lastTokenNumber')) || 0; // Load the last token number

    // Initialize UI components based on stored values
    $('#tokenNumber').val(lastTokenNumber);
    updateBillDisplay(); // Load stored bill items to the display

    loadCategories();
    loadAllItems();

    function loadCategories() {
        $.ajax({
            url: 'get_categories.php',
            type: 'GET',
            success: function (response) {
                $('#categoriesList').html(response);
                $('#categoriesList li').on('click', function () {
                    const category = $(this).data('category');
                    loadItemsByCategory(category);
                });
            },
            error: function (xhr, status, error) {
                console.error('Error loading categories:', error);
            }
        });
    }

    function loadAllItems() {
        $.ajax({
            url: 'get_items.php',
            type: 'GET',
            success: function (response) {
                $('#itemsList').html(response);
                attachItemClickHandler();
            },
            error: function (xhr, status, error) {
                console.error('Error loading items:', error);
            }
        });
    }

    function loadItemsByCategory(category) {
        $.ajax({
            url: 'get_items.php',
            type: 'GET',
            data: { category: category },
            success: function (response) {
                $('#itemsList').html(response);
                attachItemClickHandler();
            },
            error: function (xhr, status, error) {
                console.error('Error loading items:', error);
            }
        });
    }

    function attachItemClickHandler() {
        $('.item-card').on('click', function () {
            const itemName = $(this).data('name');
            const itemPrice = parseFloat($(this).data('price'));
            addToBill(itemName, itemPrice);
        });
    }

    function addToBill(name, price) {
        const existingItem = billItems.find(item => item.item === name);
        if (existingItem) {
            existingItem.quantity++;
            updateBillRow(existingItem);
        } else {
            const row = `<tr data-item="${name}">
                            <td>${name}</td>
                            <td><input type="number" class="item-qty-input" value="1" min="1"></td>
                            <td>₨<span class="item-total-price">${price}</span></td>
                            <td><button class="remove-item-btn"><i class="fa-solid fa-square-xmark"></i></button></td>
                        </tr>`;
            $('#billItems').append(row);
            billItems.push({ item: name, price: price, quantity: 1 });
        }
        updateTotal();
        saveToSessionStorage(); // Save current state to storage
    }

    function updateTotal() {
        let totalAmount = billItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        $('#totalAmount').text(`₨${totalAmount.toFixed(2)}`);
    }

    function updateBillRow(item) {
        const row = $(`#billItems tr[data-item="${item.item}"]`);
        row.find('.item-qty-input').val(item.quantity);
        const totalPrice = (item.price * item.quantity).toFixed(2);
        row.find('.item-total-price').text(totalPrice);
        updateTotal();
        saveToSessionStorage(); // Save current state to storage
    }

    $('#billItems').on('input', '.item-qty-input', function () {
        const row = $(this).closest('tr');
        const itemName = row.data('item');
        const newQuantity = parseInt($(this).val());

        const item = billItems.find(i => i.item === itemName);
        if (item) {
            item.quantity = newQuantity;
            const newTotalPrice = (item.price * newQuantity).toFixed(2);
            row.find('.item-total-price').text(newTotalPrice);
            updateTotal();
            saveToSessionStorage(); // Save current state to storage
        }
    });

    $('#billItems').on('click', '.remove-item-btn', function () {
        const row = $(this).closest('tr');
        const itemName = row.data('item');
        billItems = billItems.filter(item => item.item !== itemName);
        row.remove();
        updateTotal();
        saveToSessionStorage(); // Save current state to storage
    });

    $('#preReceiptButton, #saleReceiptButton').on('click', function () {
        const waiterName = $('#waiterName').val();
        const tableNumber = $('#tableNumber').val();

        if (!waiterName || !tableNumber) {
            alert("Please enter both waiter name and table number!");
            return;
        }

        const isSaleReceipt = $(this).attr('id') === 'saleReceiptButton';
        if (!isSaleReceipt) {
            lastTokenNumber++; // Increment token number for pre-receipt
        }

        const receiptTitle = isSaleReceipt ? "Sale Receipt" : "Pre-Receipt";
        const currentDateTime = new Date().toLocaleString();

        let receiptTotalAmount = billItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        let paymentMethod = "";
        let amountPaid = 0;
        let payback = 0;
        let discountPercentage = 0;
        let discountAmount = 0;

        // Handle the receipt generation logic...
        if (isSaleReceipt) {
            paymentMethod = prompt("Enter Payment Method (Cash, Easypaisa, JazzCash):", "Cash");

            if (!paymentMethod || !["cash", "easypaisa", "jazzcash"].includes(paymentMethod.toLowerCase())) {
                alert("Invalid payment method! Please enter Cash, Easypaisa, or JazzCash.");
                return;
            }

            discountPercentage = parseFloat(prompt("Enter discount percentage (e.g., 10 for 10%):", "0"));

            if (isNaN(discountPercentage) || discountPercentage < 0 || discountPercentage > 100) {
                alert("Invalid discount percentage! Please enter a valid number between 0 and 100.");
                return;
            }

            discountAmount = (receiptTotalAmount * discountPercentage) / 100;
            receiptTotalAmount -= discountAmount;

            if (paymentMethod.toLowerCase() === "cash") {
                amountPaid = parseFloat(prompt("Enter amount paid by customer:", "0"));
                if (isNaN(amountPaid) || amountPaid < receiptTotalAmount) {
                    alert("Insufficient payment! The total bill is ₨" + receiptTotalAmount.toFixed(2));
                    return;
                }
                payback = amountPaid - receiptTotalAmount;
            }
        }

        let receiptContent = `
            <html>
            <head>
                <title>${receiptTitle}</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        padding: 20px;
                        text-align: center;
                    }
                    .logo-container {
                        text-align: center;
                        margin-bottom: 15px;
                    }
                    .logo-container img {
                        max-width: 150px;
                        height: auto;
                    }
                    h2 {
                        margin: 10px 0;
                    }
                    table {
                        width: 100%;
                        border-collapse: collapse;
                        margin-top: 15px;
                    }
                    th, td {
                        padding: 8px;
                        text-align: left;
                    }
                    th {
                        background-color: #f0f0f0;
                    }
                    .total-container {
                        margin-top: 15px;
                        font-size: 18px;
                        font-weight: bold;
                    }
                    #datetime strong, #number strong {
                        margin-right: 15px;
                        display: inline-block;
                    }
                </style>
            </head>
            <body>

                <h2>${receiptTitle}</h2>
                <p id="datetime"><strong>Date & Time:</strong> ${currentDateTime}</p>
                <table>
                    <thead>
                        <tr>
                            <th>Item</th>
                            <th>Quantity</th>
                            <th>Price</th>
                        </tr>
                    </thead>
                    <tbody>`;

        billItems.forEach(item => {
            receiptContent += `<tr>
                                    <td>${item.item}</td>
                                    <td>${item.quantity}</td>
                                    <td>₨${(item.quantity * item.price).toFixed(2)}</td>
                                </tr>`;
        });

        receiptContent += `</tbody>
                </table>
                <div class="total-container">
                    <p><strong>Total Bill:</strong> ₨${(receiptTotalAmount + discountAmount).toFixed(2)}</p>
                    ${discountPercentage > 0 ? `<p><strong>Discount (${discountPercentage}%):</strong> ₨${discountAmount.toFixed(2)}</p>` : ''}
                    <p><strong>Amount After Discount:</strong> ₨${receiptTotalAmount.toFixed(2)}</p>
                </div>`;

        if (isSaleReceipt) {
            receiptContent += `<p><strong>Payment Method:</strong> ${paymentMethod}</p>`;

            if (paymentMethod.toLowerCase() === "cash") {
                receiptContent += `<p><strong>Amount Paid:</strong> ₨${amountPaid.toFixed(2)}</p>
                                   <p><strong>Change (Payback):</strong> ₨${payback.toFixed(2)}</p>`;
            } else {
                receiptContent += `<p><strong>Transaction Confirmed via ${paymentMethod}</strong></p>`;
            }
        }

        receiptContent += `
                <p>Thank you for your visit!</p>
            </body>
            </html>`;

        const receiptWindow = window.open('', '_blank', 'width=600,height=600');
        receiptWindow.document.write(receiptContent);
        receiptWindow.document.close();

        receiptWindow.print();
        receiptWindow.onafterprint = function () {
            receiptWindow.close();
        };

        // Save the bill after printing
        saveBill(lastTokenNumber, waiterName, tableNumber);
        saveToSessionStorage(); // Save current state to storage
    });

    function saveBill(tokenNumber, waiterName, tableNumber) {
        $.ajax({
            url: 'save_bill.php',
            type: 'POST',
            data: {
                billData: JSON.stringify(billItems),
                waiterName: waiterName,
                tableNumber: tableNumber,
                tokenNumber: tokenNumber
            },
            success: function (response) {
                let result = JSON.parse(response);
                if (result.status === "success") {
                    console.log("Bill saved successfully with Token #" + tokenNumber);
                } else {
                    console.error("Error saving bill: " + result.message);
                }
            },
            error: function (xhr, status, error) {
                console.error("Error saving bill:", error);
            }
        });
    }

    $('#restartButton').on('click', function () {
        if (billItems.length === 0) {
            alert("No data to save!");
            return;
        }

        const waiterName = $('#waiterName').val();
        const tableNumber = $('#tableNumber').val();
        const tokenNumber = lastTokenNumber;

        saveBill(tokenNumber, waiterName, tableNumber);
        resetPOS();
    });

    function resetPOS() {
        billItems = [];
        $('#billItems').empty();
        $('#totalAmount').text("₨0.00");
        $('#waiterName').val('');
        $('#tableNumber').val('');
        loadAllItems();
        saveToSessionStorage(); // Reset storage
    }

    function updateBillDisplay() {
        // Rebuild the bill view based on stored billItems
        billItems.forEach(item => {
            const row = `<tr data-item="${item.item}">
                            <td>${item.item}</td>
                            <td><input type="number" class="item-qty-input" value="${item.quantity}" min="1"></td>
                            <td>₨<span class="item-total-price">${(item.price * item.quantity).toFixed(2)}</span></td>
                            <td><button class="remove-item-btn"><i class="fa-solid fa-square-xmark"></i></button></td>
                        </tr>`;
            $('#billItems').append(row);
        });

        // Event handlers for existing items
        attachItemEvents();
        updateTotal();
    }

    function attachItemEvents() {
        $('.item-qty-input').on('input', function () {
            const row = $(this).closest('tr');
            const itemName = row.data('item');
            const newQuantity = parseInt($(this).val());

            const item = billItems.find(i => i.item === itemName);
            if (item) {
                item.quantity = newQuantity;
                const newTotalPrice = (item.price * newQuantity).toFixed(2);
                row.find('.item-total-price').text(newTotalPrice);
                updateTotal();
                saveToSessionStorage(); // Save current state to storage
            }
        });

        $('.remove-item-btn').on('click', function () {
            const row = $(this).closest('tr');
            const itemName = row.data('item');
            billItems = billItems.filter(item => item.item !== itemName);
            row.remove();
            updateTotal();
            saveToSessionStorage(); // Save current state to storage
        });
    }

    function saveToSessionStorage() {
        sessionStorage.setItem('billItems', JSON.stringify(billItems));
        sessionStorage.setItem('lastTokenNumber', lastTokenNumber);
    }
});
