<?php
$servername = "127.0.0.1";
$username = "u812793309_Admin";
$password = "bangtanseolO7";
$database = "u812793309_POS";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

function executeQuery($conn, $sql, $types = null, ...$params) {
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        return ["success" => false, "error" => "Error preparing statement: " . $conn->error];
    }
    if ($types && $params) {
        $stmt->bind_param($types, ...$params);
    }
    if (!$stmt->execute()) {
        return ["success" => false, "error" => "Error executing statement: " . $stmt->error];
    }
    $result = $stmt->get_result();
    $stmt->close();
    return ["success" => true, "result" => $result];
}

// Handle Item Addition
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["add_item"])) {
    $category = trim($_POST["category"]);
    $name = trim($_POST["name"]);
    $price = floatval($_POST["price"]);
    $imagePath = "";
    
    // Generate a unique ID
    $id = uniqid();

    if (isset($_FILES["image"]) && $_FILES["image"]["error"] == 0) {
        $allowed = ["jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png"];
        $filename = $_FILES["image"]["name"];
        $filetype = $_FILES["image"]["type"];
        $filesize = $_FILES["image"]["size"];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if (!array_key_exists($ext, $allowed)) {
            die("Error: Please select a valid file format.");
        }

        $maxsize = 5 * 1024 * 1024; // 5MB max
        if ($filesize > $maxsize) {
            die("Error: File size is larger than the allowed limit.");
        }

        if (in_array($filetype, $allowed)) {
            $targetDir = "uploads/";
            if (!file_exists($targetDir)) {
                mkdir($targetDir, 0755, true);
            }
            $newFilename = uniqid() . '.' . $ext;
            $targetFile = $targetDir . $newFilename;

            if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
                $imagePath = $targetFile;
            } else {
                echo "<script>alert('Error uploading image file.');</script>";
            }
        } else {
            echo "<script>alert('Error: There was a problem with your file.');</script>";
        }
    }

    $result = executeQuery($conn, "INSERT INTO stock (id, category, name, image_path, price) VALUES (?, ?, ?, ?, ?)", 
                         "ssssd", $id, $category, $name, $imagePath, $price);

    if ($result["success"]) {
        echo "<script>alert('Item added successfully!'); window.location.href = '".$_SERVER['PHP_SELF']."';</script>";
    } else {
        echo "<script>alert('Error adding item: " . addslashes($result["error"]) . "');</script>";
    }
    exit;
}

// Handle Item Editing
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["edit_item"])) {
    $original_name = $_POST["original_name"];
    $category = trim($_POST["category"]);
    $name = trim($_POST["name"]);
    $price = floatval($_POST["price"]);
    $imagePath = $_POST["existing_image"];

    if (isset($_FILES["image"]) && $_FILES["image"]["error"] == 0) {
        $allowed = ["jpg" => "image/jpg", "jpeg" => "image/jpeg", "gif" => "image/gif", "png" => "image/png"];
        $filename = $_FILES["image"]["name"];
        $filetype = $_FILES["image"]["type"];
        $filesize = $_FILES["image"]["size"];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

        if (!array_key_exists($ext, $allowed)) {
            die("Error: Please select a valid file format.");
        }

        $maxsize = 5 * 1024 * 1024; // 5MB max
        if ($filesize > $maxsize) {
            die("Error: File size is larger than the allowed limit.");
        }

        if (in_array($filetype, $allowed)) {
            $targetDir = "uploads/";
            if (!file_exists($targetDir)) {
                mkdir($targetDir, 0755, true);
            }
            $newFilename = uniqid() . '.' . $ext;
            $targetFile = $targetDir . $newFilename;

            if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
                $imagePath = $targetFile;
                // Delete old image if it exists and is not the default
                if (!empty($_POST["existing_image"]) && file_exists($_POST["existing_image"])) {
                    unlink($_POST["existing_image"]);
                }
            } else {
                echo "<script>alert('Error uploading image file.');</script>";
            }
        } else {
            echo "<script>alert('Error: There was a problem with your file.');</script>";
        }
    }

    $result = executeQuery($conn, "UPDATE stock SET category = ?, name = ?, image_path = ?, price = ? WHERE name = ?", 
                         "sssss", $category, $name, $imagePath, $price, $original_name);

    if ($result["success"]) {
        echo "<script>alert('Item updated successfully!'); window.location.href = '".$_SERVER['PHP_SELF']."';</script>";
    } else {
        echo "<script>alert('Error updating item: " . addslashes($result["error"]) . "');</script>";
    }
    exit;
}

// Handle Item Deletion
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["delete_name"])) {
    $delete_name = $_POST["delete_name"];
    
    // First get the image path to delete the file
    $item_result = executeQuery($conn, "SELECT image_path FROM stock WHERE name = ?", "s", $delete_name);
    if ($item_result["success"] && $item_result["result"]->num_rows > 0) {
        $item = $item_result["result"]->fetch_assoc();
        if (!empty($item['image_path']) && file_exists($item['image_path'])) {
            unlink($item['image_path']);
        }
    }
    
    $result = executeQuery($conn, "DELETE FROM stock WHERE name = ?", "s", $delete_name);
    
    if ($result["success"]) {
        echo "<script>alert('Item deleted successfully!'); window.location.href = '".$_SERVER['PHP_SELF']."';</script>";
    } else {
        echo "<script>alert('Error deleting item: " . addslashes($result["error"]) . "');</script>";
    }
    exit;
}

// Fetch all items
$items_result = executeQuery($conn, "SELECT * FROM stock ORDER BY id DESC");
$items = [];
if ($items_result["success"]) {
    $items = $items_result["result"]->fetch_all(MYSQLI_ASSOC);
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Items</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Roboto', sans-serif;
            margin: 0;
            padding: 0;
            background-color: white;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .navbar {
            background-color: black;
            color: white;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .navbar .logo img {
            height: 40px;
        }

        .navbar .nav-links {
            list-style: none;
            display: flex;
            gap: 20px;
            margin: 0;
            padding: 0;
        }

        .navbar .nav-links a {
            color: white;
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .navbar .nav-links a:hover {
            background-color: white;
            color: black;
        }

        .container {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            padding: 20px;
            justify-content: center;
        }

        .table-container {
            background-color: white;
            border-radius: 8px;
            box-shadow:1px 2px 4px rgb(225, 0, 2.1);
            padding: 20px;
            flex: 1;
            min-width: 300px;
            max-width: 800px;
        }

        .table-container h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: black;
            color: white;
        }

        tr:hover {
            background-color: #f5f5f5;
        }

        .action-btn {
            padding: 6px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            color: white;
            font-weight: 500;
            transition: background-color 0.3s;
        }

        .edit-btn {
            background-color: #FFD700;
        }

        .edit-btn:hover {
            background-color: rgb(30, 116, 92);
        }

        .delete-btn {
            background-color: #e74c3c;
        }

        .delete-btn:hover {
            background-color: #c0392b;
        }

        .add-btn {
            background-color: black;
            color: white;
            margin-bottom: 20px;
        }

        .add-btn:hover {
            background-color: #FFD700;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0,0,0,0.4);
        }

        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            max-width: 600px;
            border-radius: 8px;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }

        .close:hover {
            color: black;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }

        .form-group input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }

        .form-group img {
            max-width: 100px;
            height: auto;
            margin-top: 10px;
        }

        .submit-btn {
            background-color: black;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            font-weight: 500;
        }

        .submit-btn:hover {
            background-color: black;
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
            }
            
            .table-container {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="logo">
            <img src="logo.png" alt="Logo">
        </div>
        <ul class="nav-links">
            <li><a href="index.html"><i class="fa fa-house"></i></a></li>
            <li><a href="dashboard.html"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
        </ul>
    </nav>

    <div class="container">
        <!-- Items Table (Combined Edit/Delete) -->
        <div class="table-container">
            <h2>Manage Items</h2>
            <button class="action-btn add-btn" onclick="openAddModal()">
                <i class="fas fa-plus"></i> Add New Item
            </button>
            <table>
                <thead>
                    <tr>
                        
                        <th>Category</th>
                        <th>Name</th>
                        <th>Price</th>
                        <th>Image</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($items as $item): ?>
                    <tr>
                        
                        <td><?php echo htmlspecialchars($item['category']); ?></td>
                        <td><?php echo htmlspecialchars($item['name']); ?></td>
                        <td><?php echo number_format($item['price'], 2); ?></td>
                        <td>
                            <?php if (!empty($item['image_path'])): ?>
                                <img src="<?php echo htmlspecialchars($item['image_path']); ?>" alt="Item Image" style="max-width: 50px; max-height: 50px;">
                            <?php else: ?>
                                No Image
                            <?php endif; ?>
                        </td>
                        <td style="white-space: nowrap;">
                            <button class="action-btn edit-btn" onclick="openEditModal(
                                '<?php echo addslashes($item['name']); ?>',
                                '<?php echo addslashes($item['category']); ?>',
                                '<?php echo addslashes($item['name']); ?>',
                                '<?php echo $item['price']; ?>',
                                '<?php echo addslashes($item['image_path']); ?>'
                            )">
                                <i class="fas fa-edit"></i> Edit
                            </button>
                            <form method="POST" action="" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this item?');">
                                <input type="hidden" name="delete_name" value="<?php echo htmlspecialchars($item['name']); ?>">
                                <button type="submit" class="action-btn delete-btn">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Add Modal -->
    <div id="addModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeAddModal()">&times;</span>
            <h2>Add New Item</h2>
            <form id="addForm" method="POST" action="" enctype="multipart/form-data">
                <input type="hidden" name="add_item" value="1">
                
                <div class="form-group">
                    <label for="category">Category</label>
                    <input type="text" name="category" id="add_category" required>
                </div>
                
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="name" id="add_name" required>
                </div>
                
                <div class="form-group">
                    <label for="price">Price</label>
                    <input type="number" name="price" id="add_price" step="0.01" min="0" required>
                </div>
                
                <div class="form-group">
                    <label for="image">Image</label>
                    <input type="file" name="image" id="add_image" accept="image/*">
                </div>
                
                <button type="submit" class="submit-btn">Add Item</button>
            </form>
        </div>
    </div>

    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeEditModal()">&times;</span>
            <h2>Edit Item</h2>
            <form id="editForm" method="POST" action="" enctype="multipart/form-data">
                <input type="hidden" name="original_name" id="original_name">
                <input type="hidden" name="edit_item" value="1">
                <input type="hidden" name="existing_image" id="existing_image">
                
                <div class="form-group">
                    <label for="category">Category</label>
                    <input type="text" name="category" id="edit_category" required>
                </div>
                
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="name" id="edit_name" required>
                </div>
                
                <div class="form-group">
                    <label for="price">Price</label>
                    <input type="number" name="price" id="edit_price" step="0.01" min="0" required>
                </div>
                
                <div class="form-group">
                    <label for="image">Change Image (Leave blank to keep current)</label>
                    <input type="file" name="image" id="edit_image" accept="image/*">
                    <div id="image-preview" style="margin-top: 10px;">
                        <p>Current Image:</p>
                        <img id="current_image" src="" style="max-width: 100px; max-height: 100px; display: none;">
                    </div>
                </div>
                
                <button type="submit" class="submit-btn">Update Item</button>
            </form>
        </div>
    </div>

    <script>
        function openAddModal() {
            document.getElementById('addModal').style.display = 'block';
        }

        function closeAddModal() {
            document.getElementById('addModal').style.display = 'none';
        }

        function openEditModal(originalName, category, name, price, imagePath) {
            document.getElementById('original_name').value = originalName;
            document.getElementById('edit_category').value = category;
            document.getElementById('edit_name').value = name;
            document.getElementById('edit_price').value = price;
            document.getElementById('existing_image').value = imagePath;
            
            const imgElement = document.getElementById('current_image');
            if (imagePath) {
                imgElement.src = imagePath;
                imgElement.style.display = 'block';
            } else {
                imgElement.style.display = 'none';
            }
            
            document.getElementById('editModal').style.display = 'block';
        }

        function closeEditModal() {
            document.getElementById('editModal').style.display = 'none';
        }

        // Close modals when clicking outside
        window.onclick = function(event) {
            if (event.target == document.getElementById('addModal')) {
                closeAddModal();
            }
            if (event.target == document.getElementById('editModal')) {
                closeEditModal();
            }
        }

        // Preview image before upload in edit modal
        document.getElementById('edit_image').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(event) {
                    document.getElementById('current_image').src = event.target.result;
                    document.getElementById('current_image').style.display = 'block';
                }
                reader.readAsDataURL(file);
            }
        });
    </script>
</body>
</html>