<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $filePath = 'bills_record.json';

    
    $bills = file_exists($filePath) ? json_decode(file_get_contents($filePath), true) : [];

   
    $newBill = json_decode($_POST['billData'], true);
    if ($newBill === null) {
        echo json_encode(["status" => "error", "message" => "Invalid bill data"]);
        exit;
    }

 
    $waiterName = $_POST['waiterName'];
    $tableNumber = $_POST['tableNumber'];
    $tokenNumber = $_POST['tokenNumber']; 
    $timestamp = date("Y-m-d H:i:s");

    
    $bills[] = [
        "timestamp" => $timestamp,
        "waiterName" => $waiterName,
        "tableNumber" => $tableNumber,
        "tokenNumber" => $tokenNumber,
        "bill" => $newBill
    ];

    
    if (file_put_contents($filePath, json_encode($bills, JSON_PRETTY_PRINT))) {
        echo json_encode(["status" => "success"]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to save bill"]);
    }
}
?>