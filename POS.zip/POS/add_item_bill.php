<?php
$filePath = 'bills_record.json';

$data = json_decode(file_get_contents('php://input'), true);
$index = $data['index'];
$newItem = [
    'item' => $data['item'],
    'quantity' => $data['quantity'],
    'price' => $data['price']
];

$bills = json_decode(file_get_contents($filePath), true);

$bills[$index]['bill'][] = $newItem;

file_put_contents($filePath, json_encode($bills));

echo json_encode(['success' => true]);
?>