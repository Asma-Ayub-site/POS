<?php
$servername = "127.0.0.1";
$username = "u812793309_Admin";
$password = "bangtanseolO7";
$database = "u812793309_POS";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM stock";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$row['id']}</td>
                <td>{$row['category']}</td>
                <td>{$row['name']}</td>
                <td>{$row['price']}</td>
                <td>{$row['image_path']}</td>
                <td>
                    <div class='button-container'>
                        <button class='editButton' 
                                data-id='{$row['id']}' 
                                data-category='{$row['category']}' 
                                data-name='{$row['name']}' 
                                data-price='{$row['price']}' 
                                data-image-path='{$row['image_path']}'>
                            <i class='fas fa-edit'></i>
                        </button>
                        <button class='deleteButton' 
                                data-id='{$row['id']}' 
                                data-name='{$row['name']}'>
                            <i class='fas fa-trash'></i> 
                        </button>
                    </div>
                </td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='6'>No items found</td></tr>";
}

$conn->close();
?>